^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package launch_testing_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.15.5 (2025-10-17)
-------------------
* Fix setuptools deprecations (backport `#421 <https://github.com/ros2/examples//issues/421>`_) (`#426 <https://github.com/ros2/examples//issues/426>`_)
* Contributors: mergify[bot]

0.15.4 (2025-07-16)
-------------------

0.15.3 (2024-11-25)
-------------------
* Cleanup the launch_testing_examples. (`#374 <https://github.com/ros2/examples/issues/374>`_) (`#393 <https://github.com/ros2/examples/issues/393>`_)
* Contributors: mergify[bot]

0.15.2 (2024-07-26)
-------------------

0.15.1 (2022-11-07)
-------------------

0.15.0 (2022-03-01)
-------------------

0.14.0 (2022-01-14)
-------------------
* Readded WaitForTopics utility (`#333 <https://github.com/ros2/examples/issues/333>`_)
* Final batch of examples (`#327 <https://github.com/ros2/examples/issues/327>`_)
* Update maintainers to Aditya Pande and Shane Loretz (`#332 <https://github.com/ros2/examples/issues/332>`_)
* Updated maintainers (`#329 <https://github.com/ros2/examples/issues/329>`_)
* Contributors: Aditya Pande, Audrow Nash

0.13.0 (2021-10-18)
-------------------
* Reverted WaitForTopics utility usage (`#326 <https://github.com/ros2/examples/issues/326>`_)
* Moved examples (`#324 <https://github.com/ros2/examples/issues/324>`_)
* Contributors: Aditya Pande

0.12.0 (2021-08-05)
-------------------

0.11.2 (2021-04-26)
-------------------

0.11.1 (2021-04-12)
-------------------

0.11.0 (2021-04-06)
-------------------

0.10.3 (2021-03-18)
-------------------

0.10.2 (2021-01-25)
-------------------

0.10.1 (2020-12-10)
-------------------

0.10.0 (2020-09-21)
-------------------

0.9.2 (2020-06-01)
------------------

0.9.1 (2020-05-26)
------------------

0.9.0 (2020-04-30)
------------------

0.8.2 (2019-11-19)
------------------

0.8.1 (2019-10-24)
------------------

0.8.0 (2019-09-26)
------------------

0.7.3 (2019-05-29)
------------------

0.7.2 (2019-05-20)
------------------

0.7.1 (2019-05-08)
------------------

0.7.0 (2019-04-14)
------------------

0.6.2 (2019-02-08)
------------------

0.6.1 (2018-12-07)
------------------

0.6.0 (2018-11-20)
------------------

0.5.1 (2018-06-27)
------------------

0.5.0 (2018-06-26)
------------------

0.4.0 (2017-12-08)
------------------
