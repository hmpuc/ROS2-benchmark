// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__CASSIO_HPP_
#define CASSIO_INTERFACE__MSG__CASSIO_HPP_

#include "cassio_interface/msg/detail/cassio__struct.hpp"
#include "cassio_interface/msg/detail/cassio__builder.hpp"
#include "cassio_interface/msg/detail/cassio__traits.hpp"
#include "cassio_interface/msg/detail/cassio__type_support.hpp"

#endif  // CASSIO_INTERFACE__MSG__CASSIO_HPP_
