// generated from rosidl_generator_c/resource/idl.h.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__CASSIO_H_
#define CASSIO_INTERFACE__MSG__CASSIO_H_

#include "cassio_interface/msg/detail/cassio__struct.h"
#include "cassio_interface/msg/detail/cassio__functions.h"
#include "cassio_interface/msg/detail/cassio__type_support.h"

#endif  // CASSIO_INTERFACE__MSG__CASSIO_H_
