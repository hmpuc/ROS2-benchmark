// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice
#include "cassio_interface/msg/detail/cassio__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `sensor_name`
#include "rosidl_runtime_c/string_functions.h"
// Member `raw_data`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
cassio_interface__msg__Cassio__init(cassio_interface__msg__Cassio * msg)
{
  if (!msg) {
    return false;
  }
  // sensor_name
  if (!rosidl_runtime_c__String__init(&msg->sensor_name)) {
    cassio_interface__msg__Cassio__fini(msg);
    return false;
  }
  // hardware_id
  // sequence
  // source_timestamp_ns
  // raw_data
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->raw_data, 0)) {
    cassio_interface__msg__Cassio__fini(msg);
    return false;
  }
  return true;
}

void
cassio_interface__msg__Cassio__fini(cassio_interface__msg__Cassio * msg)
{
  if (!msg) {
    return;
  }
  // sensor_name
  rosidl_runtime_c__String__fini(&msg->sensor_name);
  // hardware_id
  // sequence
  // source_timestamp_ns
  // raw_data
  rosidl_runtime_c__uint8__Sequence__fini(&msg->raw_data);
}

bool
cassio_interface__msg__Cassio__are_equal(const cassio_interface__msg__Cassio * lhs, const cassio_interface__msg__Cassio * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // sensor_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->sensor_name), &(rhs->sensor_name)))
  {
    return false;
  }
  // hardware_id
  if (lhs->hardware_id != rhs->hardware_id) {
    return false;
  }
  // sequence
  if (lhs->sequence != rhs->sequence) {
    return false;
  }
  // source_timestamp_ns
  if (lhs->source_timestamp_ns != rhs->source_timestamp_ns) {
    return false;
  }
  // raw_data
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->raw_data), &(rhs->raw_data)))
  {
    return false;
  }
  return true;
}

bool
cassio_interface__msg__Cassio__copy(
  const cassio_interface__msg__Cassio * input,
  cassio_interface__msg__Cassio * output)
{
  if (!input || !output) {
    return false;
  }
  // sensor_name
  if (!rosidl_runtime_c__String__copy(
      &(input->sensor_name), &(output->sensor_name)))
  {
    return false;
  }
  // hardware_id
  output->hardware_id = input->hardware_id;
  // sequence
  output->sequence = input->sequence;
  // source_timestamp_ns
  output->source_timestamp_ns = input->source_timestamp_ns;
  // raw_data
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->raw_data), &(output->raw_data)))
  {
    return false;
  }
  return true;
}

cassio_interface__msg__Cassio *
cassio_interface__msg__Cassio__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cassio_interface__msg__Cassio * msg = (cassio_interface__msg__Cassio *)allocator.allocate(sizeof(cassio_interface__msg__Cassio), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(cassio_interface__msg__Cassio));
  bool success = cassio_interface__msg__Cassio__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
cassio_interface__msg__Cassio__destroy(cassio_interface__msg__Cassio * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    cassio_interface__msg__Cassio__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
cassio_interface__msg__Cassio__Sequence__init(cassio_interface__msg__Cassio__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cassio_interface__msg__Cassio * data = NULL;

  if (size) {
    data = (cassio_interface__msg__Cassio *)allocator.zero_allocate(size, sizeof(cassio_interface__msg__Cassio), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = cassio_interface__msg__Cassio__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        cassio_interface__msg__Cassio__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
cassio_interface__msg__Cassio__Sequence__fini(cassio_interface__msg__Cassio__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      cassio_interface__msg__Cassio__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

cassio_interface__msg__Cassio__Sequence *
cassio_interface__msg__Cassio__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  cassio_interface__msg__Cassio__Sequence * array = (cassio_interface__msg__Cassio__Sequence *)allocator.allocate(sizeof(cassio_interface__msg__Cassio__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = cassio_interface__msg__Cassio__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
cassio_interface__msg__Cassio__Sequence__destroy(cassio_interface__msg__Cassio__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    cassio_interface__msg__Cassio__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
cassio_interface__msg__Cassio__Sequence__are_equal(const cassio_interface__msg__Cassio__Sequence * lhs, const cassio_interface__msg__Cassio__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!cassio_interface__msg__Cassio__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
cassio_interface__msg__Cassio__Sequence__copy(
  const cassio_interface__msg__Cassio__Sequence * input,
  cassio_interface__msg__Cassio__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(cassio_interface__msg__Cassio);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    cassio_interface__msg__Cassio * data =
      (cassio_interface__msg__Cassio *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!cassio_interface__msg__Cassio__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          cassio_interface__msg__Cassio__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!cassio_interface__msg__Cassio__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
