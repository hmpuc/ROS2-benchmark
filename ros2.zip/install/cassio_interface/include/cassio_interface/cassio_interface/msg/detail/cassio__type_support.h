// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_H_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "cassio_interface/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_cassio_interface
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  cassio_interface,
  msg,
  Cassio
)();

#ifdef __cplusplus
}
#endif

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_H_
