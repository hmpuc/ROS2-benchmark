// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TRAITS_HPP_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "cassio_interface/msg/detail/cassio__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace cassio_interface
{

namespace msg
{

inline void to_flow_style_yaml(
  const Cassio & msg,
  std::ostream & out)
{
  out << "{";
  // member: sensor_name
  {
    out << "sensor_name: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_name, out);
    out << ", ";
  }

  // member: hardware_id
  {
    out << "hardware_id: ";
    rosidl_generator_traits::value_to_yaml(msg.hardware_id, out);
    out << ", ";
  }

  // member: sequence
  {
    out << "sequence: ";
    rosidl_generator_traits::value_to_yaml(msg.sequence, out);
    out << ", ";
  }

  // member: source_timestamp_ns
  {
    out << "source_timestamp_ns: ";
    rosidl_generator_traits::value_to_yaml(msg.source_timestamp_ns, out);
    out << ", ";
  }

  // member: raw_data
  {
    if (msg.raw_data.size() == 0) {
      out << "raw_data: []";
    } else {
      out << "raw_data: [";
      size_t pending_items = msg.raw_data.size();
      for (auto item : msg.raw_data) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Cassio & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: sensor_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor_name: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor_name, out);
    out << "\n";
  }

  // member: hardware_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hardware_id: ";
    rosidl_generator_traits::value_to_yaml(msg.hardware_id, out);
    out << "\n";
  }

  // member: sequence
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sequence: ";
    rosidl_generator_traits::value_to_yaml(msg.sequence, out);
    out << "\n";
  }

  // member: source_timestamp_ns
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "source_timestamp_ns: ";
    rosidl_generator_traits::value_to_yaml(msg.source_timestamp_ns, out);
    out << "\n";
  }

  // member: raw_data
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.raw_data.size() == 0) {
      out << "raw_data: []\n";
    } else {
      out << "raw_data:\n";
      for (auto item : msg.raw_data) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Cassio & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace cassio_interface

namespace rosidl_generator_traits
{

[[deprecated("use cassio_interface::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const cassio_interface::msg::Cassio & msg,
  std::ostream & out, size_t indentation = 0)
{
  cassio_interface::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use cassio_interface::msg::to_yaml() instead")]]
inline std::string to_yaml(const cassio_interface::msg::Cassio & msg)
{
  return cassio_interface::msg::to_yaml(msg);
}

template<>
inline const char * data_type<cassio_interface::msg::Cassio>()
{
  return "cassio_interface::msg::Cassio";
}

template<>
inline const char * name<cassio_interface::msg::Cassio>()
{
  return "cassio_interface/msg/Cassio";
}

template<>
struct has_fixed_size<cassio_interface::msg::Cassio>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<cassio_interface::msg::Cassio>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<cassio_interface::msg::Cassio>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TRAITS_HPP_
