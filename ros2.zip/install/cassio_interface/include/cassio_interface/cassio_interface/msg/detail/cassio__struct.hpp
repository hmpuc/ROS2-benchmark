// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_HPP_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__cassio_interface__msg__Cassio __attribute__((deprecated))
#else
# define DEPRECATED__cassio_interface__msg__Cassio __declspec(deprecated)
#endif

namespace cassio_interface
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Cassio_
{
  using Type = Cassio_<ContainerAllocator>;

  explicit Cassio_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_name = "";
      this->hardware_id = 0ul;
      this->sequence = 0ull;
      this->source_timestamp_ns = 0ll;
    }
  }

  explicit Cassio_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : sensor_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor_name = "";
      this->hardware_id = 0ul;
      this->sequence = 0ull;
      this->source_timestamp_ns = 0ll;
    }
  }

  // field types and members
  using _sensor_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _sensor_name_type sensor_name;
  using _hardware_id_type =
    uint32_t;
  _hardware_id_type hardware_id;
  using _sequence_type =
    uint64_t;
  _sequence_type sequence;
  using _source_timestamp_ns_type =
    int64_t;
  _source_timestamp_ns_type source_timestamp_ns;
  using _raw_data_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _raw_data_type raw_data;

  // setters for named parameter idiom
  Type & set__sensor_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->sensor_name = _arg;
    return *this;
  }
  Type & set__hardware_id(
    const uint32_t & _arg)
  {
    this->hardware_id = _arg;
    return *this;
  }
  Type & set__sequence(
    const uint64_t & _arg)
  {
    this->sequence = _arg;
    return *this;
  }
  Type & set__source_timestamp_ns(
    const int64_t & _arg)
  {
    this->source_timestamp_ns = _arg;
    return *this;
  }
  Type & set__raw_data(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->raw_data = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    cassio_interface::msg::Cassio_<ContainerAllocator> *;
  using ConstRawPtr =
    const cassio_interface::msg::Cassio_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<cassio_interface::msg::Cassio_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<cassio_interface::msg::Cassio_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      cassio_interface::msg::Cassio_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<cassio_interface::msg::Cassio_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      cassio_interface::msg::Cassio_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<cassio_interface::msg::Cassio_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<cassio_interface::msg::Cassio_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<cassio_interface::msg::Cassio_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__cassio_interface__msg__Cassio
    std::shared_ptr<cassio_interface::msg::Cassio_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__cassio_interface__msg__Cassio
    std::shared_ptr<cassio_interface::msg::Cassio_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Cassio_ & other) const
  {
    if (this->sensor_name != other.sensor_name) {
      return false;
    }
    if (this->hardware_id != other.hardware_id) {
      return false;
    }
    if (this->sequence != other.sequence) {
      return false;
    }
    if (this->source_timestamp_ns != other.source_timestamp_ns) {
      return false;
    }
    if (this->raw_data != other.raw_data) {
      return false;
    }
    return true;
  }
  bool operator!=(const Cassio_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Cassio_

// alias to use template instance with default allocator
using Cassio =
  cassio_interface::msg::Cassio_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace cassio_interface

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_HPP_
