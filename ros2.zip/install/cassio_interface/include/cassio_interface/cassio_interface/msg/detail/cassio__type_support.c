// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "cassio_interface/msg/detail/cassio__rosidl_typesupport_introspection_c.h"
#include "cassio_interface/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "cassio_interface/msg/detail/cassio__functions.h"
#include "cassio_interface/msg/detail/cassio__struct.h"


// Include directives for member types
// Member `sensor_name`
#include "rosidl_runtime_c/string_functions.h"
// Member `raw_data`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  cassio_interface__msg__Cassio__init(message_memory);
}

void cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_fini_function(void * message_memory)
{
  cassio_interface__msg__Cassio__fini(message_memory);
}

size_t cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__size_function__Cassio__raw_data(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_const_function__Cassio__raw_data(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_function__Cassio__raw_data(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__fetch_function__Cassio__raw_data(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_const_function__Cassio__raw_data(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__assign_function__Cassio__raw_data(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_function__Cassio__raw_data(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__resize_function__Cassio__raw_data(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_member_array[5] = {
  {
    "sensor_name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cassio_interface__msg__Cassio, sensor_name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "hardware_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cassio_interface__msg__Cassio, hardware_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sequence",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cassio_interface__msg__Cassio, sequence),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "source_timestamp_ns",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cassio_interface__msg__Cassio, source_timestamp_ns),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "raw_data",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(cassio_interface__msg__Cassio, raw_data),  // bytes offset in struct
    NULL,  // default value
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__size_function__Cassio__raw_data,  // size() function pointer
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_const_function__Cassio__raw_data,  // get_const(index) function pointer
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__get_function__Cassio__raw_data,  // get(index) function pointer
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__fetch_function__Cassio__raw_data,  // fetch(index, &value) function pointer
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__assign_function__Cassio__raw_data,  // assign(index, value) function pointer
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__resize_function__Cassio__raw_data  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_members = {
  "cassio_interface__msg",  // message namespace
  "Cassio",  // message name
  5,  // number of fields
  sizeof(cassio_interface__msg__Cassio),
  cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_member_array,  // message members
  cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_init_function,  // function to initialize message memory (memory has to be allocated)
  cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_type_support_handle = {
  0,
  &cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_cassio_interface
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, cassio_interface, msg, Cassio)() {
  if (!cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_type_support_handle.typesupport_identifier) {
    cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &cassio_interface__msg__Cassio__rosidl_typesupport_introspection_c__Cassio_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
