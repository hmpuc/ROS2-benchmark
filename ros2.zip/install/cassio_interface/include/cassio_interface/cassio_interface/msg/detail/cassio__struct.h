// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_H_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'sensor_name'
#include "rosidl_runtime_c/string.h"
// Member 'raw_data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/Cassio in the package cassio_interface.
typedef struct cassio_interface__msg__Cassio
{
  rosidl_runtime_c__String sensor_name;
  uint32_t hardware_id;
  uint64_t sequence;
  int64_t source_timestamp_ns;
  rosidl_runtime_c__uint8__Sequence raw_data;
} cassio_interface__msg__Cassio;

// Struct for a sequence of cassio_interface__msg__Cassio.
typedef struct cassio_interface__msg__Cassio__Sequence
{
  cassio_interface__msg__Cassio * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} cassio_interface__msg__Cassio__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__STRUCT_H_
