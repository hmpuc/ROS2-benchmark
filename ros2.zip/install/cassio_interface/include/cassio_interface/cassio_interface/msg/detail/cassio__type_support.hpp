// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_HPP_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "cassio_interface/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_cassio_interface
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  cassio_interface,
  msg,
  Cassio
)();
#ifdef __cplusplus
}
#endif

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__TYPE_SUPPORT_HPP_
