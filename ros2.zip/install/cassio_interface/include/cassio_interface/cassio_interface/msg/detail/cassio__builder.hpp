// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from cassio_interface:msg/Cassio.idl
// generated code does not contain a copyright notice

#ifndef CASSIO_INTERFACE__MSG__DETAIL__CASSIO__BUILDER_HPP_
#define CASSIO_INTERFACE__MSG__DETAIL__CASSIO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "cassio_interface/msg/detail/cassio__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace cassio_interface
{

namespace msg
{

namespace builder
{

class Init_Cassio_raw_data
{
public:
  explicit Init_Cassio_raw_data(::cassio_interface::msg::Cassio & msg)
  : msg_(msg)
  {}
  ::cassio_interface::msg::Cassio raw_data(::cassio_interface::msg::Cassio::_raw_data_type arg)
  {
    msg_.raw_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::cassio_interface::msg::Cassio msg_;
};

class Init_Cassio_source_timestamp_ns
{
public:
  explicit Init_Cassio_source_timestamp_ns(::cassio_interface::msg::Cassio & msg)
  : msg_(msg)
  {}
  Init_Cassio_raw_data source_timestamp_ns(::cassio_interface::msg::Cassio::_source_timestamp_ns_type arg)
  {
    msg_.source_timestamp_ns = std::move(arg);
    return Init_Cassio_raw_data(msg_);
  }

private:
  ::cassio_interface::msg::Cassio msg_;
};

class Init_Cassio_sequence
{
public:
  explicit Init_Cassio_sequence(::cassio_interface::msg::Cassio & msg)
  : msg_(msg)
  {}
  Init_Cassio_source_timestamp_ns sequence(::cassio_interface::msg::Cassio::_sequence_type arg)
  {
    msg_.sequence = std::move(arg);
    return Init_Cassio_source_timestamp_ns(msg_);
  }

private:
  ::cassio_interface::msg::Cassio msg_;
};

class Init_Cassio_hardware_id
{
public:
  explicit Init_Cassio_hardware_id(::cassio_interface::msg::Cassio & msg)
  : msg_(msg)
  {}
  Init_Cassio_sequence hardware_id(::cassio_interface::msg::Cassio::_hardware_id_type arg)
  {
    msg_.hardware_id = std::move(arg);
    return Init_Cassio_sequence(msg_);
  }

private:
  ::cassio_interface::msg::Cassio msg_;
};

class Init_Cassio_sensor_name
{
public:
  Init_Cassio_sensor_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Cassio_hardware_id sensor_name(::cassio_interface::msg::Cassio::_sensor_name_type arg)
  {
    msg_.sensor_name = std::move(arg);
    return Init_Cassio_hardware_id(msg_);
  }

private:
  ::cassio_interface::msg::Cassio msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::cassio_interface::msg::Cassio>()
{
  return cassio_interface::msg::builder::Init_Cassio_sensor_name();
}

}  // namespace cassio_interface

#endif  // CASSIO_INTERFACE__MSG__DETAIL__CASSIO__BUILDER_HPP_
