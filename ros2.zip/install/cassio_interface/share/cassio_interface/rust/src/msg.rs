#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to cassio_interface__msg__Cassio

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Cassio {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub hardware_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub source_timestamp_ns: i64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_data: Vec<u8>,

}



impl Default for Cassio {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Cassio::default())
  }
}

impl rosidl_runtime_rs::Message for Cassio {
  type RmwMsg = super::msg::rmw::Cassio;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        sensor_name: msg.sensor_name.as_str().into(),
        hardware_id: msg.hardware_id,
        sequence: msg.sequence,
        source_timestamp_ns: msg.source_timestamp_ns,
        raw_data: msg.raw_data.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        sensor_name: msg.sensor_name.as_str().into(),
      hardware_id: msg.hardware_id,
      sequence: msg.sequence,
      source_timestamp_ns: msg.source_timestamp_ns,
        raw_data: msg.raw_data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      sensor_name: msg.sensor_name.to_string(),
      hardware_id: msg.hardware_id,
      sequence: msg.sequence,
      source_timestamp_ns: msg.source_timestamp_ns,
      raw_data: msg.raw_data
          .into_iter()
          .collect(),
    }
  }
}


