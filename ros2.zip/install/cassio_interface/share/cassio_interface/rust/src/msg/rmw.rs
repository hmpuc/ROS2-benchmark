#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "cassio_interface__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__cassio_interface__msg__Cassio() -> *const std::ffi::c_void;
}

#[link(name = "cassio_interface__rosidl_generator_c")]
extern "C" {
    fn cassio_interface__msg__Cassio__init(msg: *mut Cassio) -> bool;
    fn cassio_interface__msg__Cassio__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Cassio>, size: usize) -> bool;
    fn cassio_interface__msg__Cassio__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Cassio>);
    fn cassio_interface__msg__Cassio__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Cassio>, out_seq: *mut rosidl_runtime_rs::Sequence<Cassio>) -> bool;
}

// Corresponds to cassio_interface__msg__Cassio
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Cassio {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub hardware_id: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sequence: u64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub source_timestamp_ns: i64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for Cassio {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !cassio_interface__msg__Cassio__init(&mut msg as *mut _) {
        panic!("Call to cassio_interface__msg__Cassio__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Cassio {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cassio_interface__msg__Cassio__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cassio_interface__msg__Cassio__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { cassio_interface__msg__Cassio__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Cassio {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Cassio where Self: Sized {
  const TYPE_NAME: &'static str = "cassio_interface/msg/Cassio";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__cassio_interface__msg__Cassio() }
  }
}


