# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(cassio_interface_IDL_FILES "msg/Cassio.idl")
set(cassio_interface_INTERFACE_FILES "msg/Cassio.msg")
