# generated from rosidl_generator_py/resource/_idl.py.em
# with input from cassio_interface:msg/Cassio.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'raw_data'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Cassio(type):
    """Metaclass of message 'Cassio'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('cassio_interface')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'cassio_interface.msg.Cassio')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__cassio
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__cassio
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__cassio
            cls._TYPE_SUPPORT = module.type_support_msg__msg__cassio
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__cassio

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class Cassio(metaclass=Metaclass_Cassio):
    """Message class 'Cassio'."""

    __slots__ = [
        '_sensor_name',
        '_hardware_id',
        '_sequence',
        '_source_timestamp_ns',
        '_raw_data',
    ]

    _fields_and_field_types = {
        'sensor_name': 'string',
        'hardware_id': 'uint32',
        'sequence': 'uint64',
        'source_timestamp_ns': 'int64',
        'raw_data': 'sequence<uint8>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint64'),  # noqa: E501
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('uint8')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.sensor_name = kwargs.get('sensor_name', str())
        self.hardware_id = kwargs.get('hardware_id', int())
        self.sequence = kwargs.get('sequence', int())
        self.source_timestamp_ns = kwargs.get('source_timestamp_ns', int())
        self.raw_data = array.array('B', kwargs.get('raw_data', []))

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.sensor_name != other.sensor_name:
            return False
        if self.hardware_id != other.hardware_id:
            return False
        if self.sequence != other.sequence:
            return False
        if self.source_timestamp_ns != other.source_timestamp_ns:
            return False
        if self.raw_data != other.raw_data:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def sensor_name(self):
        """Message field 'sensor_name'."""
        return self._sensor_name

    @sensor_name.setter
    def sensor_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'sensor_name' field must be of type 'str'"
        self._sensor_name = value

    @builtins.property
    def hardware_id(self):
        """Message field 'hardware_id'."""
        return self._hardware_id

    @hardware_id.setter
    def hardware_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'hardware_id' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'hardware_id' field must be an unsigned integer in [0, 4294967295]"
        self._hardware_id = value

    @builtins.property
    def sequence(self):
        """Message field 'sequence'."""
        return self._sequence

    @sequence.setter
    def sequence(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'sequence' field must be of type 'int'"
            assert value >= 0 and value < 18446744073709551616, \
                "The 'sequence' field must be an unsigned integer in [0, 18446744073709551615]"
        self._sequence = value

    @builtins.property
    def source_timestamp_ns(self):
        """Message field 'source_timestamp_ns'."""
        return self._source_timestamp_ns

    @source_timestamp_ns.setter
    def source_timestamp_ns(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'source_timestamp_ns' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'source_timestamp_ns' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._source_timestamp_ns = value

    @builtins.property
    def raw_data(self):
        """Message field 'raw_data'."""
        return self._raw_data

    @raw_data.setter
    def raw_data(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'B', \
                "The 'raw_data' array.array() must have the type code of 'B'"
            self._raw_data = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 256 for val in value)), \
                "The 'raw_data' field must be a set or sequence and each value of type 'int' and each unsigned integer in [0, 255]"
        self._raw_data = array.array('B', value)
