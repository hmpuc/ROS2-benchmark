from cassio_interface.msg._cassio import Cassio  # noqa: F401
